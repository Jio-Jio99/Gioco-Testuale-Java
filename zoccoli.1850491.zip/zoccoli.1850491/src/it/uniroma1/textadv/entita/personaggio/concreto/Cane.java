package it.uniroma1.textadv.entita.personaggio.concreto;

import it.uniroma1.textadv.entita.personaggio.Animale;

public class Cane extends Animale {

	public Cane(String nome) {
		super(nome);
		verso = "BAU BAU BAU... penso voglia ancora coccole!";
	}
	
	
	@Override
	public String guarda() {
		return "... ricambia lo sguardo e inclina la testa";
	}
}
