/**
 * Package che contiene tutte le entità che rappresentano i personaggi
 */
package it.uniroma1.textadv.entita.personaggio;