/**
 * Package che contiene tutti i personaggi concreti 
 */
package it.uniroma1.textadv.entita.personaggio.concreto;