package it.uniroma1.textadv.entita.interfaccia;

/**
 * Interfaccia identificativa per raccogliere tutti gli oggetti (ed eventuali animali) appartenenti ad un Personaggio
 * @author gioele
 *
 */
public interface Inventario {}
