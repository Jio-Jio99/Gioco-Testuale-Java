package it.uniroma1.textadv.entita.oggetto.concreto;

import it.uniroma1.textadv.entita.oggetto.Contenitore;

/**
 * Classe che rappresenta il contenitore Armadio
 * @author gioele
 *
 */
public class Armadio extends Contenitore {

	public Armadio(String nome) {
		super(nome);
	}
}
