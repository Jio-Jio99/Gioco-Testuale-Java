/**
 * Package che contiene tutti gli oggetti  instanzaibili del mondo
 */
package it.uniroma1.textadv.entita.oggetto;