/**
 * Sotto-pacchetto contente due classi per la creazione delle stanza:
 * <pre> Classi:
 * - {@link it.uniroma1.textadv.entita.stanza.Stanza}
 * - {@link it.uniroma1.textadv.entita.stanza.StanzaBuilder}
 * </pre> 
 */
package it.uniroma1.textadv.entita.stanza;