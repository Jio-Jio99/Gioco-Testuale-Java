/**
 * Package che contiene tutti i link concreti instanziabili
 */
package it.uniroma1.textadv.entita.link.concreto;