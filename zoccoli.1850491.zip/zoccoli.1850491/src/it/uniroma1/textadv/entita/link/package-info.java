/**
 * Package che contiene tutti i link del mondo instanziato
 */
package it.uniroma1.textadv.entita.link;