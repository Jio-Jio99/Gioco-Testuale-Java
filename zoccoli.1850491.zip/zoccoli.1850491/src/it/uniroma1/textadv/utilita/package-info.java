/**
 * Questo pacchetto conterrà i pacchetti e le sotto classi per avviare il caricamento del gioco e gestire le azioni
 */
package it.uniroma1.textadv.utilita;