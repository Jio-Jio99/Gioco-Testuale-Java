/**
 * Pacchetto contente tutte le eccezioni sollevate durante il carimento del gioco
 */
package it.uniroma1.textadv.utilita.creazione.eccezioni;