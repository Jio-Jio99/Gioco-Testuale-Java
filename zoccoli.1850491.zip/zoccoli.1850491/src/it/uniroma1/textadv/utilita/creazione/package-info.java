/**
 * Pacchetto contenente tutte le classi utili per il caricamento del mondo e delle sue entita
 */
package it.uniroma1.textadv.utilita.creazione;