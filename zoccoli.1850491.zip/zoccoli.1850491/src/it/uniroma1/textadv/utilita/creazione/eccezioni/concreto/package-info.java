/**
 * Sotto-pacchetto di eccezioni concrete lanciate durante il caricamento
 * @author gioele
 */
package it.uniroma1.textadv.utilita.creazione.eccezioni.concreto;