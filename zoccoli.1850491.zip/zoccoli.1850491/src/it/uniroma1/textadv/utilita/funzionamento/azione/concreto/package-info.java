/**
 * Sotto-pacchetto contenente le azioni concrete implementate nel gioco
 */
package it.uniroma1.textadv.utilita.funzionamento.azione.concreto;