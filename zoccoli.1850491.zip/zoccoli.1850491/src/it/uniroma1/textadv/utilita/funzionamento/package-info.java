/**
 * Pacchetto che contiene tutte le classi per gestire il corretto funzionamento delle azioni, con la classe madre {@link it.uniroma1.textadv.utilita.funzionamento.AnalizzaComando}
 * @author gioele
 */
package it.uniroma1.textadv.utilita.funzionamento;