/**
 * Pacchetto contente tutte le eccezioni sollevate durante il gioco
 */
package it.uniroma1.textadv.utilita.funzionamento.eccezioni;