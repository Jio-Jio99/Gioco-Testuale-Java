/**
 * Sotto-pacchetto contenente le vere e proprie azioni del gioco
 */
package it.uniroma1.textadv.utilita.funzionamento.azione;