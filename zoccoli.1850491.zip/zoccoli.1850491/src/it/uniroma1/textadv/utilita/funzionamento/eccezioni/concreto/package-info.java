/**
 * Sotto-pacchetto di eccezioni sull'azione concrete
 * @author gioele
 */
package it.uniroma1.textadv.utilita.funzionamento.eccezioni.concreto;