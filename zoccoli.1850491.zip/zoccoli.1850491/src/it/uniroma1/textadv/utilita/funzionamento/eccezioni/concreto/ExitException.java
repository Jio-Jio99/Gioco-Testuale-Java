package it.uniroma1.textadv.utilita.funzionamento.eccezioni.concreto;

import it.uniroma1.textadv.utilita.funzionamento.eccezioni.AzioneException;

/**
 * Eccezione lanciata in caso in cui il giocatore voglia concludere prima il gioco
 * @author gioele
 *
 */
public class ExitException extends AzioneException{}
